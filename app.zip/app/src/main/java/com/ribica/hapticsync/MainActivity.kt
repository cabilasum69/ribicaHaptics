package com.ribica.hapticsync

import android.Manifest
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.Socket
import java.net.URL
import java.nio.ByteOrder
import java.util.Locale
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.math.abs
import kotlin.math.max

class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "MainActivityDebug"

        private const val VIBRATION_CHANNEL = 3
        private const val TOP_DB = 30.0
        private const val ANALYSIS_FRAME_LEN = 1024
        private const val ANALYSIS_HOP = 256

        private const val SYNC_OFFSET_MS = 0L
        private const val LOOP_PLAYBACK = false
        private const val ALLOW_FANCY_EFFECTS = true

        private const val PWM_PERIOD_MS = 50L
        private const val PWM_MIN_ON_MS = 4L
        private const val PWM_FULL_ON_AMPLITUDE = 245

        private const val ENV_ON_THRESHOLD = 0.03
        private const val SMOOTH_LEVELS = 8
        // Long-note recognition: dropouts inside one long vibration must not split it into mini vibrations
        private const val GAP_ALWAYS_MS = 30.0   // gaps this short are always bridged
        private const val GAP_LONG_MS = 80.0     // gaps this short are bridged if next to a long note
        private const val GAP_FRAG_MAX_MS = 100.0 // fragmented long note: largest gap that may be bridged
        private const val GAP_RATIO = 0.5        // ...and only if gap <= 50% of the SHORTER neighbouring raw piece
        private const val SUSTAIN_FALL_MS = 250.0 // inside a long note amplitude may fall at most 1.0 per 250 ms
        private const val LIVE_CHUNK_MAX_MS = 2000L // long note goes out in one vibrate() call
        private const val LEGACY_LONG_FULL_ON = true // old motors: long notes are always solid full-on (no PWM = no trembling)
        private const val LONG_NOTE_MS = 120.0   // what counts as a long note
        private const val STRENGTH_LEVELS = 6

        // Live haptic channel mode
        private const val LIVE_SEG_MS_AMP = 8L          // segment length on devices with amplitude control
        private const val LIVE_SEG_MS_LEGACY = 20L      // segment length for PWM on old motors (4.4)
        private const val LIVE_CHUNK_MS = 400L          // how much vibration is sent per call (longer = fewer restarts = smoother)
        private const val LIVE_RENEW_MARGIN_MS = 60L    // next chunk is sent this early so there is no gap
        private const val LIVE_OFFSET_MS = 0L           // + = vibration later, - = vibration earlier (sync tweak)
        private const val LIVE_LOOKAHEAD_MS = 3000L     // how far ahead of playback the decoder may run
        private const val LIVE_DEADBAND = 0.10          // ignore amplitude changes smaller than 6% (removes trembling)
        private const val LIVE_REF_FLOOR = 0.03
        private const val LIVE_REF_DECAY_PER_SEC = 0.99

        private val THEME_SOURCES = listOf(
            "Galaxy S26 Ultra" to "https://3.onj.me/phonetones/unzipped/Samsung/Galaxy-S26-Ultra/ringtones/SoundTheme/",
            "Galaxy S25 Ultra" to "https://3.onj.me/phonetones/unzipped/Samsung/Galaxy-S25-Ultra/audio/ringtones/SoundTheme/",
            "Galaxy S24 Ultra" to "https://3.onj.me/phonetones/unzipped/Samsung/Galaxy-S24-Ultra/audio/ringtones/SoundTheme/",
            "Galaxy S23 Ultra" to "https://3.onj.me/phonetones/unzipped/Samsung/Galaxy-S23-Ultra/audio/ringtones/SoundTheme/"
        )
    }

    private data class OnlineEntry(val name: String, val url: String, val isDir: Boolean)

    private enum class PlaybackMode {
        SOUND_AND_VIBRATION,
        SOUND_ONLY,
        VIBRATION_ONLY
    }

    data class WavData(
        val channels: Int,
        val sampleRate: Int,
        val samples: ShortArray
    )

    private data class PatternResult(
        val durations: LongArray,
        val strengths: DoubleArray,
        val shaped: BooleanArray = BooleanArray(durations.size),
        val ramps: Int = 0
    )

    private class EnvCfg(
        val tolerance: Double,
        val tapMaxMs: Double,
        val minStepMs: Double,
        val minOnMs: Double,
        val minGapMs: Double,
        val shapeMinSpread: Double,
        val fadeMinMs: Double = 150.0
    )

    private class FancySeg(var startMs: Double, var endMs: Double, var strength: Double, var shaped: Boolean)

    // Envelope of the haptic channel, filled by the decoder thread just ahead of playback.
    private class LiveEnv {
        private var buf = FloatArray(4096)
        @Volatile var count = 0
            private set
        @Volatile var done = false
        @Volatile var error: String? = null
        @Volatile var frameMs = 8.0

        fun add(v: Float) {
            synchronized(this) {
                if (count == buf.size) buf = buf.copyOf(buf.size * 2)
                buf[count] = v
                count = count + 1
            }
        }

        fun get(i: Int): Float = synchronized(this) { if (i in 0 until count) buf[i] else 0f }
    }

    private val CFG_ACH_FINE = EnvCfg(0.10, 30.0, 20.0, 8.0, 12.0, 0.2)
    private val CFG_OTHER_FINE = EnvCfg(0.12, 40.0, 30.0, 14.0, 12.0, 2.0)
    private val CFG_COARSE = EnvCfg(0.25, 30.0, 40.0, 20.0, 25.0, 2.0)

    private var selectedUri: Uri? = null
    private lateinit var txtStatus: TextView
    private lateinit var btnPlay: Button
    private lateinit var btnStop: Button
    private lateinit var seekIntensity: SeekBar
    private lateinit var txtIntensityLabel: TextView
    private lateinit var radioGroupSource: RadioGroup
    private lateinit var radioGroupMode: RadioGroup

    private var mediaPlayer: MediaPlayer? = null
    private var systemVibrator: Vibrator? = null
    private var isPlayingState = false
    private var lastAudioPos = 0

    private var lastPattern = LongArray(0)
    private var lastStrength = DoubleArray(0)
    private var lastShaped = BooleanArray(0)
    private var lastPatternFancy = false

    private var fancyHaptics = false
    private var hasAmpControl = false
    @Volatile private var vibrationAmplitude = 255
    private var vibrationStartMs = 0L
    private var lastLiveUpdateMs = 0L

    private var liveEnabled = false
    private var suppressLiveListener = false
    private val liveLock = Any()
    @Volatile private var liveRunId = 0
    @Volatile private var liveRunning = false
    @Volatile private var liveAnchor = Long.MIN_VALUE
    @Volatile private var liveRebuild = false
    private var resumeOnRecreate = false
    private var pendingAutoPlay = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var loadToken = 0

    private val pickFileLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            loadAndAnalyze(uri)
        } else {
            Toast.makeText(this, "No file selected.", Toast.LENGTH_SHORT).show()
        }
    }

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            setAsRingtone()
        } else {
            Toast.makeText(this, "Storage permission is needed to set a ringtone.", Toast.LENGTH_LONG).show()
        }
    }

    private fun isDarkNow(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        applySystemBarColors()

        systemVibrator = getVibratorService()
        hasAmpControl = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            (systemVibrator?.hasAmplitudeControl() == true)
        fancyHaptics = ALLOW_FANCY_EFFECTS && hasAmpControl

        txtStatus = findViewById(R.id.txtStatus)
        btnPlay = findViewById(R.id.btnPlay)
        btnStop = findViewById(R.id.btnStop)
        seekIntensity = findViewById(R.id.seekIntensity)
        txtIntensityLabel = findViewById(R.id.txtIntensityLabel)
        radioGroupSource = findViewById(R.id.radioGroupSource)
        radioGroupMode = findViewById(R.id.radioGroupMode)
        val btnPick = findViewById<Button>(R.id.btnPick)
        val btnBrowseOnline = findViewById<Button>(R.id.btnBrowseOnline)
        val btnSetRingtone = findViewById<Button>(R.id.btnSetRingtone)

        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        liveEnabled = prefs.getBoolean("live_haptic", false)
        val switchLive = findViewById<Switch>(R.id.switchLive)
        switchLive.isChecked = liveEnabled
        switchLive.setOnCheckedChangeListener { button, checked ->
            if (suppressLiveListener) return@setOnCheckedChangeListener
            if (checked) {
                suppressLiveListener = true
                button.isChecked = false
                suppressLiveListener = false
                AlertDialog.Builder(this)
                    .setTitle("Live haptic channel")
                    .setMessage(
                        "Experimental. Instead of analyzing the whole file first, the haptic channel " +
                            "is read in real time while playing.\n\n" +
                            "This overrides the current vibration settings (pre-analyzed pattern, fade effects). " +
                            "Vibration follows the level of the channel, and the Intensity slider is the maximum.\n\n" +
                            "On phones without amplitude control, weaker levels are made by pulsing the motor.\n\n" +
                            "Works with the Samsung source only."
                    )
                    .setPositiveButton("Enable") { _, _ ->
                        suppressLiveListener = true
                        switchLive.isChecked = true
                        suppressLiveListener = false
                        setLiveEnabled(true)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            } else {
                setLiveEnabled(false)
            }
        }

        fun updateBrowseVisibility() {
            btnBrowseOnline.visibility = if (isSamsungSourceSelected()) View.VISIBLE else View.GONE
        }
        updateBrowseVisibility()
        radioGroupSource.setOnCheckedChangeListener { _, _ ->
            updateBrowseVisibility()
            selectedUri?.let { loadAndAnalyze(it) }
        }

        btnStop.isEnabled = false

        radioGroupMode.setOnCheckedChangeListener { _, _ ->
            if (isPlayingState) playAndVibrate()
        }

        btnPick.setOnClickListener {
            pickFileLauncher.launch(
                arrayOf(
                    "audio/*", "audio/ogg", "audio/x-ogg",
                    "application/ogg", "application/x-ogg",
                    "video/ogg", "application/octet-stream", "*/*"
                )
            )
        }
        btnBrowseOnline.setOnClickListener { showOnlineBrowser() }
        btnPlay.setOnClickListener { playAndVibrate() }
        btnStop.setOnClickListener { stopPlaybackAndVibration(showToast = true) }
        btnSetRingtone.setOnClickListener { setAsRingtone() }

        seekIntensity.max = 254
        seekIntensity.progress = vibrationAmplitude - 1
        updateIntensityLabel()

        seekIntensity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                vibrationAmplitude = (progress + 1).coerceIn(1, 255)
                updateIntensityLabel()
                if (!fromUser) return
                if (isPlayingState) {
                    applyLiveIntensity(force = false)
                } else {
                    systemVibrator?.cancel()
                    previewVibration()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (isPlayingState) applyLiveIntensity(force = true)
            }
        })

        // Rotation / recreate: bring back the loaded file (and playback) instead of "nothing loaded"
        val restoredUri = savedInstanceState?.getString("uri")
        if (restoredUri != null) {
            pendingAutoPlay = savedInstanceState.getBoolean("playing", false)
            mainHandler.post {
                if (!isFinishing && selectedUri == null) loadAndAnalyze(Uri.parse(restoredUri))
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        selectedUri?.let { outState.putString("uri", it.toString()) }
        outState.putBoolean("playing", resumeOnRecreate)
    }

    override fun onPause() {
        resumeOnRecreate = isPlayingState
        super.onPause()
        stopPlaybackAndVibration()
    }

    // The system (volume keys / volume panel) can cancel our vibration. Bring it back.
    private fun resumeVibrationAfterSystemCancel() {
        if (!isPlayingState) return
        if (getSelectedPlaybackMode() == PlaybackMode.SOUND_ONLY) return
        if (isLiveActive()) {
            liveRebuild = true
        } else {
            startVibration(currentPlaybackPositionMs())
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val handled = super.onKeyDown(keyCode, event)
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) && isPlayingState) {
            mainHandler.postDelayed({ resumeVibrationAfterSystemCancel() }, 120L)
            mainHandler.postDelayed({ resumeVibrationAfterSystemCancel() }, 500L)
        }
        return handled
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && isPlayingState) {
            mainHandler.postDelayed({ resumeVibrationAfterSystemCancel() }, 150L)
        }
    }

    private fun consumeAutoPlay() {
        if (pendingAutoPlay) {
            pendingAutoPlay = false
            playAndVibrate()
        }
    }

    override fun onStop() {
        super.onStop()
        stopPlaybackAndVibration()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPlaybackAndVibration()
    }

    @Suppress("DEPRECATION")
    private fun applySystemBarColors() {
        val bg = resources.getColor(R.color.bg)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.statusBarColor = bg
            window.navigationBarColor = bg
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }
        var flags = window.decorView.systemUiVisibility
        val lightBars = !isDarkNow()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = if (lightBars) {
                flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            } else {
                flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            flags = if (lightBars) {
                flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            } else {
                flags and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            }
        }
        window.decorView.systemUiVisibility = flags
    }

    private fun getSelectedPlaybackMode(): PlaybackMode = when (radioGroupMode.checkedRadioButtonId) {
        R.id.rbSoundOnly -> PlaybackMode.SOUND_ONLY
        R.id.rbVibrationOnly -> PlaybackMode.VIBRATION_ONLY
        else -> PlaybackMode.SOUND_AND_VIBRATION
    }

    private fun updateIntensityLabel() {
        val percent = (vibrationAmplitude * 100) / 255
        txtIntensityLabel.text = "Intensity: $percent%"
    }

    private fun isSamsungSourceSelected(): Boolean =
        radioGroupSource.checkedRadioButtonId == R.id.rbSourceSamsung

    private fun loadAndAnalyze(uri: Uri) {
        stopPlaybackAndVibration()
        selectedUri = uri
        if (isLiveActive()) {
            loadToken++
            txtStatus.text = "${displayName(uri)}\nLive haptic channel · ready (no pre-analysis)"
            btnPlay.isEnabled = true
            consumeAutoPlay()
            return
        }
        val samsungMode = isSamsungSourceSelected()
        val fancy = fancyHaptics
        val name = displayName(uri)
        val token = ++loadToken
        txtStatus.text = "$name\nDecoding..."
        btnPlay.isEnabled = false
        Log.d(TAG, "loadAndAnalyze() uri=$uri, samsungMode=$samsungMode")

        Thread {
            var status = ""
            var result: PatternResult? = null
            try {
                val wav = decodeAudioToPcm(uri)
                val requiredChannels = if (samsungMode) VIBRATION_CHANNEL else 1
                if (wav.channels < requiredChannels) {
                    status = "$name\nNo haptic channel in this file (${wav.channels} channel(s)).\nTry the \"Other\" source."
                } else {
                    val chanIndex = if (samsungMode) VIBRATION_CHANNEL - 1 else 0
                    val generated = when {
                        samsungMode && fancy -> generateFancyPattern(wav, chanIndex)
                        samsungMode -> generateChannelPattern(wav, chanIndex)
                        else -> generateOtherPattern(wav, fancy)
                    }
                    if (generated.durations.isEmpty()) {
                        status = "$name\nNo vibration found in this file."
                    } else {
                        result = generated
                        val totalFrames = wav.samples.size / wav.channels
                        val durationSec = totalFrames.toDouble() / wav.sampleRate
                        val durationText = String.format(Locale.US, "%.1f", durationSec)
                        val sourceLabel = if (samsungMode) "Samsung haptic channel" else "Beat detection"
                        val fxText = if (samsungMode && fancy) " · ${generated.ramps} fade effect(s)" else ""
                        status = "$name\n$sourceLabel · ${generated.durations.size} segments$fxText · $durationText s"
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception in loadAndAnalyze", e)
                status = "$name\nCould not read this file: ${e.message}"
            }

            val finalStatus = status
            val finalResult = result
            runOnUiThread {
                if (token != loadToken || isFinishing) return@runOnUiThread
                txtStatus.text = finalStatus
                if (finalResult != null) {
                    lastPattern = finalResult.durations
                    lastStrength = finalResult.strengths
                    lastShaped = finalResult.shaped
                    lastPatternFancy = fancy
                    btnPlay.isEnabled = true
                    consumeAutoPlay()
                }
            }
        }.start()
    }

    private fun displayName(uri: Uri): String {
        try {
            if (uri.scheme == "content") {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) {
                            val n = c.getString(idx)
                            if (!n.isNullOrEmpty()) return n
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "displayName failed", e)
        }
        val last = uri.lastPathSegment?.substringAfterLast('/') ?: return "audio file"
        return if (uri.scheme == "file") cleanName(last) else last
    }

    private fun cleanName(raw: String): String {
        var n = try { Uri.decode(raw) } catch (e: Exception) { raw }
        n = n.trimEnd('/')
        n = n.replace(Regex("\\.ogg$", RegexOption.IGNORE_CASE), "")
        n = n.replace('_', ' ')
        n = n.replace(Regex("\\bACH\\b", RegexOption.IGNORE_CASE), " ")
        n = n.replace(Regex("\\s+"), " ").trim()
        return if (n.isEmpty()) raw else n
    }

    private fun openConnection(url: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        if (conn is HttpsURLConnection && Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            conn.sslSocketFactory = Tls12SocketFactory(conn.sslSocketFactory)
        }
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.requestMethod = "GET"
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android; Mobile)")
        return conn
    }

    private fun showOnlineBrowser() {
        val names = THEME_SOURCES.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choose phone model")
            .setItems(names) { _, which -> fetchAndShowFolder(THEME_SOURCES[which].second) }
            .show()
    }

    private fun fetchAndShowFolder(url: String, depth: Int = 0) {
        txtStatus.text = "Loading list..."
        Thread {
            try {
                val entries = fetchListing(url)
                mainHandler.post { showFolderDialog(entries, depth) }
            } catch (e: Exception) {
                mainHandler.post { txtStatus.text = "Failed to load list: ${e.message}" }
            }
        }.start()
    }

    private fun fetchListing(urlStr: String): List<OnlineEntry> {
        val conn = openConnection(urlStr)
        conn.instanceFollowRedirects = true
        val html = conn.inputStream.bufferedReader().use { it.readText() }
        conn.disconnect()

        val hrefRegex = Regex("href=[\"']?([^\"' >]+)[\"']?", RegexOption.IGNORE_CASE)
        val entries = ArrayList<OnlineEntry>()
        for (match in hrefRegex.findAll(html)) {
            val href = match.groupValues[1]
            if (href.startsWith("?") || href.startsWith("/") || href == "../" || href.startsWith("http")) continue
            val fullUrl = urlStr.trimEnd('/') + "/" + href
            when {
                href.endsWith("/") -> entries.add(OnlineEntry(href.trimEnd('/'), fullUrl, true))
                href.endsWith(".ogg", ignoreCase = true) -> entries.add(OnlineEntry(href, fullUrl, false))
            }
        }
        return entries
    }

    private fun showFolderDialog(entries: List<OnlineEntry>, depth: Int) {
        if (entries.isEmpty()) {
            txtStatus.text = "Nothing found here."
            return
        }
        val isThemeList = depth == 0 && entries.any { it.isDir }
        val labels = entries.map { cleanName(it.name) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(if (isThemeList) "Choose Sound Theme" else "Choose Ringtone")
            .setItems(labels) { _, which ->
                val entry = entries[which]
                if (entry.isDir) {
                    fetchAndShowFolder(entry.url, depth + 1)
                } else {
                    downloadAndLoad(entry.url, entry.name)
                }
            }
            .show()
    }

    private fun downloadAndLoad(fileUrl: String, fileName: String) {
        txtStatus.text = "Downloading ${cleanName(fileName)}..."
        btnPlay.isEnabled = false
        Thread {
            try {
                val conn = openConnection(fileUrl)
                val outFile = File(cacheDir, fileName)
                BufferedInputStream(conn.inputStream).use { input ->
                    FileOutputStream(outFile).use { output -> input.copyTo(output) }
                }
                conn.disconnect()
                mainHandler.post { loadAndAnalyze(Uri.fromFile(outFile)) }
            } catch (e: Exception) {
                mainHandler.post { txtStatus.text = "Download failed: ${e.message}" }
            }
        }.start()
    }

    private fun setAsRingtone() {
        val uri = selectedUri
        if (uri == null) {
            Toast.makeText(this, "Choose or download a file first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(this)) {
            Toast.makeText(this, "Allow \"Modify system settings\" for this app first.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }

        Thread {
            try {
                val displayName = "ribicaHaptics_${System.currentTimeMillis()}.ogg"
                val newUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    insertRingtoneScoped(uri, displayName)
                } else {
                    insertRingtoneLegacy(uri, displayName)
                }
                RingtoneManager.setActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE, newUri)

                mainHandler.post {
                    Toast.makeText(this, "Ringtone set.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                mainHandler.post {
                    Toast.makeText(this, "Ringtone failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun insertRingtoneScoped(source: Uri, displayName: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, "audio/ogg")
            put(MediaStore.Audio.Media.IS_RINGTONE, true)
            put(MediaStore.Audio.Media.IS_NOTIFICATION, false)
            put(MediaStore.Audio.Media.IS_ALARM, false)
            put(MediaStore.Audio.Media.IS_MUSIC, false)
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_RINGTONES)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val newUri = contentResolver.insert(collection, values)
            ?: throw Exception("Could not create MediaStore entry")

        contentResolver.openOutputStream(newUri)?.use { out ->
            contentResolver.openInputStream(source)?.use { input -> input.copyTo(out) }
        } ?: throw Exception("Could not open output stream")

        val doneValues = ContentValues()
        doneValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
        contentResolver.update(newUri, doneValues, null, null)
        return newUri
    }

    @Suppress("DEPRECATION")
    private fun insertRingtoneLegacy(source: Uri, displayName: String): Uri {
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RINGTONES)
        if (!dir.exists() && !dir.mkdirs()) throw Exception("Could not create Ringtones folder")
        val outFile = File(dir, displayName)

        contentResolver.openInputStream(source)?.use { input ->
            FileOutputStream(outFile).use { out -> input.copyTo(out) }
        } ?: throw Exception("Could not read the source file")

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DATA, outFile.absolutePath)
            put(MediaStore.MediaColumns.TITLE, displayName.removeSuffix(".ogg"))
            put(MediaStore.MediaColumns.MIME_TYPE, "audio/ogg")
            put(MediaStore.Audio.Media.IS_RINGTONE, true)
            put(MediaStore.Audio.Media.IS_NOTIFICATION, false)
            put(MediaStore.Audio.Media.IS_ALARM, false)
            put(MediaStore.Audio.Media.IS_MUSIC, false)
        }
        return contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw Exception("Could not create MediaStore entry")
    }

    private fun stopPlaybackAndVibration(showToast: Boolean = false) {
        isPlayingState = false
        synchronized(liveLock) { liveRunId++ }
        liveRunning = false
        liveAnchor = Long.MIN_VALUE
        if (::btnStop.isInitialized) btnStop.isEnabled = false
        mainHandler.removeCallbacksAndMessages(null)

        try {
            systemVibrator?.cancel()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to cancel vibration", e)
        }

        try {
            mediaPlayer?.let { mp ->
                if (mp.isPlaying) mp.stop()
                mp.reset()
                mp.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to stop media player", e)
        } finally {
            mediaPlayer = null
        }

        if (showToast) {
            Toast.makeText(this, "Stopped.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun playAndVibrate() {
        val uri = selectedUri
        if (uri == null || (lastPattern.isEmpty() && !isLiveActive())) {
            Toast.makeText(this, "No file or vibration pattern yet.", Toast.LENGTH_SHORT).show()
            return
        }

        stopPlaybackAndVibration()
        isPlayingState = true
        btnStop.isEnabled = true

        val mode = getSelectedPlaybackMode()
        if (isLiveActive()) {
            playLive(mode)
            return
        }
        if (mode == PlaybackMode.VIBRATION_ONLY) {
            runVibrationOnlyCycle()
            return
        }

        try {
            val mp = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                isLooping = false
                setOnPreparedListener { player ->
                    if (!isPlayingState || mediaPlayer !== player) {
                        player.release()
                        return@setOnPreparedListener
                    }
                    player.start()
                    startWrapWatcher(player)
                    if (mode != PlaybackMode.SOUND_ONLY) {
                        mainHandler.post {
                            if (isPlayingState && mediaPlayer === player) {
                                startVibration(currentPlaybackPositionMs() + SYNC_OFFSET_MS)
                            }
                        }
                    }
                }
                setOnCompletionListener { player ->
                    if (LOOP_PLAYBACK && isPlayingState && mediaPlayer === player) {
                        try { systemVibrator?.cancel() } catch (_: Exception) {}
                        player.seekTo(0)
                    } else {
                        stopPlaybackAndVibration()
                    }
                }
                setOnSeekCompleteListener { player ->
                    if (LOOP_PLAYBACK && isPlayingState && mediaPlayer === player) {
                        if (mode != PlaybackMode.SOUND_ONLY) startVibration()
                        player.start()
                        lastAudioPos = 0
                    }
                }
                setOnErrorListener { _, _, _ ->
                    stopPlaybackAndVibration()
                    true
                }
            }
            mediaPlayer = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            stopPlaybackAndVibration()
            Toast.makeText(this, "Playback failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun runVibrationOnlyCycle() {
        startVibration()
        val totalMs = lastPattern.sum()
        mainHandler.postDelayed({
            if (isPlayingState && mediaPlayer == null) {
                if (LOOP_PLAYBACK) runVibrationOnlyCycle() else stopPlaybackAndVibration()
            }
        }, totalMs + 50L)
    }

    private fun startWrapWatcher(player: MediaPlayer) {
        lastAudioPos = 0
        val watcher = object : Runnable {
            override fun run() {
                if (!isPlayingState || mediaPlayer !== player) return
                try {
                    val pos = player.currentPosition
                    if (liveRunning) syncLiveClock(pos.toLong())
                    if (pos + 300 < lastAudioPos) {
                        Log.d(TAG, "Audio wrapped: $lastAudioPos -> $pos, loop=$LOOP_PLAYBACK")
                        if (LOOP_PLAYBACK) {
                            systemVibrator?.cancel()
                            if (getSelectedPlaybackMode() != PlaybackMode.SOUND_ONLY) startVibration()
                        } else {
                            stopPlaybackAndVibration()
                            return
                        }
                    }
                    lastAudioPos = pos
                } catch (e: Exception) {
                    Log.e(TAG, "Wrap watcher failed", e)
                    return
                }
                mainHandler.postDelayed(this, 50L)
            }
        }
        mainHandler.post(watcher)
    }

    private fun getVibratorService(): Vibrator {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vm.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    private fun vibrateOneShot(durationMs: Long, amplitude: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            systemVibrator?.vibrate(VibrationEffect.createOneShot(durationMs, amplitude))
        } else {
            @Suppress("DEPRECATION")
            systemVibrator?.vibrate(durationMs)
        }
    }

    private fun vibrateLegacyPattern(vib: Vibrator, legacy: LongArray) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vib.vibrate(VibrationEffect.createWaveform(legacy, -1))
        } else {
            @Suppress("DEPRECATION")
            vib.vibrate(legacy, -1)
        }
    }

    private fun previewVibration() {
        val amp = vibrationAmplitude
        if (hasAmpControl) {
            vibrateOneShot(120L, amp)
            return
        }
        val vib = systemVibrator ?: return
        try {
            vibrateLegacyPattern(vib, buildLegacyPattern(longArrayOf(160L), intArrayOf(amp)))
        } catch (e: Exception) {
            Log.e(TAG, "previewVibration failed", e)
        }
    }

    private fun startVibration(requestedOffsetMs: Long = 0L) {
        val vib = systemVibrator ?: return
        val offsetMs = requestedOffsetMs.coerceAtLeast(0L)
        var skipped = 0L
        var first = 0
        while (first < lastPattern.size && skipped + lastPattern[first] <= offsetMs) {
            skipped += lastPattern[first]
            first++
        }
        if (first >= lastPattern.size) return

        val rawPattern = lastPattern.copyOfRange(first, lastPattern.size)
        rawPattern[0] = rawPattern[0] - (offsetMs - skipped)
        val strength = lastStrength.copyOfRange(first, lastStrength.size)
        val shaped = lastShaped.copyOfRange(first, lastShaped.size)
        val rawAmps = buildAmplitudes(rawPattern, strength, shaped, vibrationAmplitude, lastPatternFancy)
        val (pattern, amps) = mergeEqualAmps(rawPattern, rawAmps)

        vibrationStartMs = SystemClock.elapsedRealtime() - offsetMs
        Log.d(TAG, "PATTERN offset=$offsetMs segs=${pattern.size} hasAmp=$hasAmpControl fancy=$lastPatternFancy first30ms=${pattern.take(30)} first30amp=${amps.take(30)}")
        try {
            if (hasAmpControl) {
                vib.vibrate(VibrationEffect.createWaveform(pattern, amps, -1))
            } else {
                vibrateLegacyPattern(vib, buildLegacyPattern(pattern, amps))
            }
        } catch (e: Exception) {
            Log.e(TAG, "startVibration failed", e)
        }
    }

    private fun currentPlaybackPositionMs(): Long {
        val player = mediaPlayer
        if (player != null) {
            try {
                return player.currentPosition.toLong()
            } catch (e: Exception) {
                Log.w(TAG, "currentPosition failed", e)
            }
        }
        return SystemClock.elapsedRealtime() - vibrationStartMs
    }

    private fun applyLiveIntensity(force: Boolean) {
        if (getSelectedPlaybackMode() == PlaybackMode.SOUND_ONLY) return
        if (isLiveActive()) { liveRebuild = true; return }
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastLiveUpdateMs < 150L) return
        lastLiveUpdateMs = now
        // No cancel() here: a new vibrate() replaces the old one without a gap
        startVibration(currentPlaybackPositionMs())
    }

    private fun mergeEqualAmps(timings: LongArray, amps: IntArray): Pair<LongArray, IntArray> {
        val t = ArrayList<Long>()
        val a = ArrayList<Int>()
        for (i in timings.indices) {
            if (timings[i] <= 0L) continue
            val amp = amps.getOrElse(i) { 0 }
            if (a.isNotEmpty() && a[a.size - 1] == amp) {
                t[t.size - 1] = t[t.size - 1] + timings[i]
            } else {
                t.add(timings[i])
                a.add(amp)
            }
        }
        if (t.isEmpty()) {
            t.add(1L)
            a.add(0)
        }
        return Pair(t.toLongArray(), a.toIntArray())
    }

    // ---------------- Live haptic channel mode ----------------

    private fun isLiveActive(): Boolean = liveEnabled && isSamsungSourceSelected()

    private fun setLiveEnabled(enabled: Boolean) {
        liveEnabled = enabled
        getSharedPreferences("settings", Context.MODE_PRIVATE)
            .edit().putBoolean("live_haptic", enabled).apply()
        stopPlaybackAndVibration()
        selectedUri?.let { loadAndAnalyze(it) }
        Toast.makeText(
            this,
            if (enabled) "Live haptic channel on." else "Live haptic channel off.",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun liveNowMs(): Long {
        val a = liveAnchor
        return if (a == Long.MIN_VALUE) 0L else SystemClock.elapsedRealtime() - a
    }

    // Keeps our own clock steady between the 50 ms player position reads.
    private fun syncLiveClock(playerPosMs: Long) {
        val target = SystemClock.elapsedRealtime() - playerPosMs
        val cur = liveAnchor
        if (cur == Long.MIN_VALUE) return
        val d = target - cur
        liveAnchor = if (abs(d) > 80L) target else cur + d / 10
    }

    private fun playLive(mode: PlaybackMode) {
        val uri = selectedUri ?: return
        val runId = liveRunId
        val wantVib = mode != PlaybackMode.SOUND_ONLY
        val env = LiveEnv()
        if (wantVib) startLiveDecode(uri, env, runId)
        if (mode == PlaybackMode.VIBRATION_ONLY) {
            awaitLiveReady(env, runId, null)
            return
        }
        try {
            val mp = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                isLooping = false
                setOnPreparedListener { player ->
                    if (runId != liveRunId || !isPlayingState || mediaPlayer !== player) {
                        player.release()
                        return@setOnPreparedListener
                    }
                    if (wantVib) {
                        awaitLiveReady(env, runId, player)
                    } else {
                        player.start()
                        startWrapWatcher(player)
                    }
                }
                setOnCompletionListener { player ->
                    if (mediaPlayer === player) stopPlaybackAndVibration()
                }
                setOnErrorListener { _, _, _ ->
                    stopPlaybackAndVibration()
                    true
                }
            }
            mediaPlayer = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            stopPlaybackAndVibration()
            Toast.makeText(this, "Playback failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // Waits until the decoder is a bit ahead, then starts sound and vibration together.
    private fun awaitLiveReady(env: LiveEnv, runId: Int, player: MediaPlayer?, waitedMs: Long = 0L) {
        if (runId != liveRunId || !isPlayingState) return
        val err = env.error
        if (err != null) {
            txtStatus.text = err
            stopPlaybackAndVibration()
            return
        }
        val ready = env.done || env.count * env.frameMs >= LIVE_CHUNK_MS + 200.0
        if (!ready && waitedMs < 2500L) {
            mainHandler.postDelayed({ awaitLiveReady(env, runId, player, waitedMs + 15L) }, 15L)
            return
        }
        if (player != null) {
            player.start()
            liveAnchor = SystemClock.elapsedRealtime() - player.currentPosition
            startWrapWatcher(player)
        } else {
            liveAnchor = SystemClock.elapsedRealtime()
        }
        startLiveVibrationThread(env, runId)
    }

    @Suppress("DEPRECATION")
    private fun startLiveDecode(uri: Uri, env: LiveEnv, runId: Int) {
        Thread {
            var extractor: MediaExtractor? = null
            var codec: MediaCodec? = null
            try {
                val ex = MediaExtractor()
                extractor = ex
                ex.setDataSource(this, uri, null)

                var trackIndex = -1
                var found: MediaFormat? = null
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val m = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (m.startsWith("audio/")) {
                        trackIndex = i
                        found = f
                        break
                    }
                }
                val format: MediaFormat = found ?: run {
                    env.error = "No audio track found in this file"
                    return@Thread
                }
                ex.selectTrack(trackIndex)

                var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                if (channels < VIBRATION_CHANNEL) {
                    env.error = "No haptic channel in this file ($channels channel(s)).\nTry the \"Other\" source."
                    return@Thread
                }

                val c = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
                codec = c
                c.configure(format, null, null, 0)
                c.start()

                val info = MediaCodec.BufferInfo()
                val useNew = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
                val inBufs = if (useNew) null else c.inputBuffers
                var outBufs = if (useNew) null else c.outputBuffers

                var winLen = max(16, (sampleRate * 0.008).toInt())
                env.frameMs = winLen * 1000.0 / sampleRate
                var decay = Math.pow(LIVE_REF_DECAY_PER_SEC, env.frameMs / 1000.0)
                var ref = LIVE_REF_FLOOR
                val chIdx = VIBRATION_CHANNEL - 1
                var sampleIdx = 0
                var winPeak = 0
                var winCount = 0
                val subPeaks = IntArray(3)
                var subIdx = 0
                var inEos = false
                var outEos = false

                while (!outEos && runId == liveRunId) {
                    if (!inEos) {
                        val ii = c.dequeueInputBuffer(10000L)
                        if (ii >= 0) {
                            val ib = if (useNew) c.getInputBuffer(ii)!! else inBufs!![ii]
                            ib.clear()
                            val sz = ex.readSampleData(ib, 0)
                            if (sz < 0) {
                                c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inEos = true
                            } else {
                                c.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                                ex.advance()
                            }
                        }
                    }

                    var oi = c.dequeueOutputBuffer(info, 10000L)
                    while (oi != MediaCodec.INFO_TRY_AGAIN_LATER) {
                        when {
                            oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                                val nf = c.outputFormat
                                channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                                val nsr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                                if (channels < VIBRATION_CHANNEL) {
                                    env.error = "No haptic channel in this file ($channels channel(s)).\nTry the \"Other\" source."
                                    return@Thread
                                }
                                if (nsr != sampleRate) {
                                    sampleRate = nsr
                                    winLen = max(16, (sampleRate * 0.008).toInt())
                                    env.frameMs = winLen * 1000.0 / sampleRate
                                    decay = Math.pow(LIVE_REF_DECAY_PER_SEC, env.frameMs / 1000.0)
                                    winPeak = 0
                                    winCount = 0
                                    java.util.Arrays.fill(subPeaks, 0)
                                }
                                sampleIdx = 0
                            }
                            oi == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> {
                                if (!useNew) outBufs = c.outputBuffers
                            }
                            oi >= 0 -> {
                                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outEos = true
                                if (info.size > 0) {
                                    val ob = if (useNew) c.getOutputBuffer(oi)!! else outBufs!![oi]
                                    ob.position(info.offset)
                                    ob.limit(info.offset + info.size)
                                    ob.order(ByteOrder.LITTLE_ENDIAN)
                                    var p = ob.position()
                                    val lim = ob.limit() - 1
                                    while (p < lim) {
                                        val v = ob.getShort(p).toInt()
                                        p += 2
                                        if (sampleIdx == chIdx) {
                                            val a = if (v < 0) -v else v
                                            if (a > winPeak) winPeak = a
                                            winCount++
                                            if (winCount >= winLen) {
                                                if (env.count < 400 && env.count % 25 == 0) Log.d(TAG, "LIVEDEC ch=$channels sr=$sampleRate chIdx=$chIdx frame=${env.count} rawPeak=$winPeak ref=$ref")
                                                subPeaks[subIdx] = winPeak
                                                subIdx = (subIdx + 1) % subPeaks.size
                                                val peak = max(subPeaks[0], max(subPeaks[1], subPeaks[2])) / 32768.0
                                                ref = max(ref * decay, max(peak, LIVE_REF_FLOOR))
                                                env.add((peak / ref).coerceIn(0.0, 1.0).toFloat())
                                                winPeak = 0
                                                winCount = 0
                                            }
                                        }
                                        sampleIdx++
                                        if (sampleIdx >= channels) sampleIdx = 0
                                    }
                                    ob.clear()
                                }
                                c.releaseOutputBuffer(oi, false)
                                // Do not run far ahead of playback (saves battery, avoids UI hiccups)
                                while (runId == liveRunId &&
                                    env.count * env.frameMs > liveNowMs() + LIVE_LOOKAHEAD_MS
                                ) {
                                    Thread.sleep(20L)
                                }
                            }
                        }
                        oi = c.dequeueOutputBuffer(info, 0)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Live decode failed", e)
                if (runId == liveRunId && env.error == null) env.error = "Live decode failed: ${e.message}"
            } finally {
                env.done = true
                try { codec?.stop() } catch (_: Exception) {}
                try { codec?.release() } catch (_: Exception) {}
                try { extractor?.release() } catch (_: Exception) {}
            }
        }.start()
    }

    // Amplitude is quantized into a few stable levels with hysteresis, so the motor
    // holds one level instead of constantly re-targeting (that re-targeting is the "trembling").
    private fun buildLiveChunk(env: LiveEnv, startMs: Long, n: Int, segMs: Long, maxAmp: Int): IntArray {
        val out = IntArray(n)
        val frameMs = env.frameMs
        val levels = SMOOTH_LEVELS
        var prevL = 0
        var prevX = 0.0
        // Local copy with padding on both sides (decoder runs ~3 s ahead, so we can look ahead)
        val padMs = 300.0
        val first = Math.floor((startMs - padMs) / frameMs).toInt()
        val nf = ((n * segMs + 2 * padMs) / frameMs).toInt() + 3
        val local = DoubleArray(nf) { env.get(first + it).toDouble() }
        closeGaps(local, frameMs)
        val solid = solidifyLongRuns(local, frameMs)
        for (i in 0 until n) {
            val a = ((startMs + i * segMs) / frameMs).toInt()
            val b = max(a + 1, ((startMs + (i + 1) * segMs) / frameMs).toInt())
            var mx = 0f
            var sum = 0f
            var solidHere = false
            for (k in a until b) {
                val li = k - first
                val v = if (li in 0 until nf) local[li].toFloat() else 0f
                if (v > mx) mx = v
                sum += v
                if (li in 0 until nf && solid[li]) solidHere = true
            }
            val s = if (hasAmpControl) mx.toDouble() else 0.5 * mx + 0.5 * (sum / (b - a))
            var x = if (s < ENV_ON_THRESHOLD) 0.0 else Math.pow(s, 0.7) * levels
            // slow release: at most ~1.2 level drop per 8 ms
            if (prevX > 0.0 && x < prevX) x = max(x, prevX - 1.2 * segMs / 8.0)
            prevX = x
            var l: Int
            if (x <= 0.0) {
                l = 0
            } else if (prevL > 0 && abs(x - prevL) < 0.8) {
                l = prevL // hysteresis: stay on current level
            } else {
                l = Math.round(x).toInt().coerceIn(1, levels)
            }
            out[i] = if (l == 0) 0 else (maxAmp * l / levels).coerceAtLeast(1)
            // Long note on an old motor: solid full-on. Any weaker level would be PWM pulsing = trembling.
            if (l > 0 && solidHere && !hasAmpControl && LEGACY_LONG_FULL_ON) out[i] = 255
            prevL = l
        }
        return out
    }

    private fun startLiveVibrationThread(env: LiveEnv, runId: Int) {
        val vib = systemVibrator ?: return
        liveRunning = true
        val ampMode = hasAmpControl
        val segMs = if (ampMode) LIVE_SEG_MS_AMP else LIVE_SEG_MS_LEGACY
        val minN = (LIVE_CHUNK_MS / segMs).toInt()
        Thread {
            try {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
            } catch (_: Exception) {}
            var chunkEnd = Long.MIN_VALUE
            var silent = false
            try {
                while (runId == liveRunId) {
                    val t = liveNowMs() + LIVE_OFFSET_MS
                    if (env.done && t > env.count * env.frameMs + 150.0) {
                        mainHandler.post { if (runId == liveRunId) stopPlaybackAndVibration() }
                        break
                    }
                    if (chunkEnd == Long.MIN_VALUE || t >= chunkEnd - LIVE_RENEW_MARGIN_MS || liveRebuild) {
                        liveRebuild = false
                        val aheadMs = env.count * env.frameMs - t
                        val usableMs = if (env.done) LIVE_CHUNK_MAX_MS.toDouble()
                                       else minOf(LIVE_CHUNK_MAX_MS.toDouble(), aheadMs - 350.0)
                        val n = max(minN, (usableMs / segMs).toInt())
                        val amps = buildLiveChunk(env, t, n, segMs, vibrationAmplitude.coerceIn(1, 255))
                        val any = amps.any { it > 0 }
                        Log.d(TAG, "LIVE t=${t}ms frames=${env.count} n=$n segMs=$segMs ampMode=$ampMode amps=${amps.take(25)}")
                        synchronized(liveLock) {
                            if (runId != liveRunId) return@Thread
                            if (!any) {
                                if (!silent) vib.cancel()
                                silent = true
                            } else {
                                silent = false
                                val timings = LongArray(n) { segMs }
                                if (ampMode) {
                                    val (tm, am) = mergeEqualAmps(timings, amps)
                                    vib.vibrate(VibrationEffect.createWaveform(tm, am, -1))
                                } else {
                                    vibrateLegacyPattern(vib, buildLegacyPattern(timings, amps))
                                }
                            }
                        }
                        chunkEnd = t + n * segMs
                    }
                    Thread.sleep(6L)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Live vibration thread failed", e)
            }
        }.start()
    }

    private fun buildAmplitudes(
        pattern: LongArray,
        strength: DoubleArray,
        shaped: BooleanArray,
        amplitude: Int,
        fancy: Boolean
    ): IntArray {
        val amps = IntArray(pattern.size)
        val maxAmp = amplitude.coerceIn(1, 255)

        if (fancy) {
            val floorAmp = minOf(6, maxAmp)
            for (i in pattern.indices) {
                val s = strength.getOrElse(i) { 0.0 }.coerceIn(0.0, 1.0)
                val isShaped = shaped.getOrElse(i) { false }
                amps[i] = when {
                    s <= 0.0 -> 0
                    !isShaped -> maxAmp
                    else -> {
                        val l = Math.round(Math.pow(s, 0.7) * SMOOTH_LEVELS).toInt().coerceIn(1, SMOOTH_LEVELS)
                        (maxAmp * l / SMOOTH_LEVELS).coerceAtLeast(floorAmp.coerceAtMost(maxAmp))
                    }
                }
            }
            return amps
        }

        val minAmp = (maxAmp * 0.35).toInt().coerceIn(1, maxAmp)
        for (i in pattern.indices) {
            val s = strength.getOrElse(i) { 0.0 }.coerceIn(0.0, 1.0)
            amps[i] = when {
                s <= 0.0 -> 0
                LEGACY_LONG_FULL_ON && pattern[i] >= LONG_NOTE_MS.toLong() -> 255
                else -> (minAmp + s * (maxAmp - minAmp)).toInt().coerceIn(1, 255)
            }
        }
        return amps
    }

    private fun buildLegacyPattern(pattern: LongArray, amps: IntArray): LongArray {
        val out = ArrayList<Long>()
        var lastOn = false

        fun add(on: Boolean, ms: Long) {
            if (ms <= 0L) return
            if (out.isEmpty()) {
                if (on) {
                    out.add(0L)
                    out.add(ms)
                } else {
                    out.add(ms)
                }
                lastOn = on
                return
            }
            if (on == lastOn) {
                out[out.size - 1] = out[out.size - 1] + ms
            } else {
                out.add(ms)
                lastOn = on
            }
        }

        for (i in pattern.indices) {
            val dur = pattern[i]
            val amp = amps.getOrElse(i) { 0 }
            val duty = (amp / 255.0).coerceIn(0.0, 1.0)
            when {
                amp <= 0 -> add(false, dur)
                amp >= PWM_FULL_ON_AMPLITUDE -> add(true, dur)
                dur < PWM_PERIOD_MS * 2 -> {
                    val on = maxOf(PWM_MIN_ON_MS, (dur * duty).toLong())
                    if (on >= dur) {
                        add(true, dur)
                    } else {
                        add(true, on)
                        add(false, dur - on)
                    }
                }
                else -> {
                    val onSlice = maxOf(PWM_MIN_ON_MS, (duty * PWM_PERIOD_MS).toLong())
                    val offSlice = PWM_PERIOD_MS - onSlice
                    if (offSlice <= 0L) {
                        add(true, dur)
                    } else {
                        var left = dur
                        while (left > 0L) {
                            val on = minOf(onSlice, left)
                            add(true, on)
                            left -= on
                            if (left <= 0L) break
                            val off = minOf(offSlice, left)
                            add(false, off)
                            left -= off
                        }
                    }
                }
            }
        }
        if (out.isEmpty()) out.add(0L)
        return out.toLongArray()
    }

    private fun decodeAudioToPcm(uri: Uri): WavData {
        val extractor = MediaExtractor()
        extractor.setDataSource(this, uri, null)

        var trackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) {
                trackIndex = i
                format = f
                break
            }
        }
        require(trackIndex >= 0 && format != null) { "No audio track found in this file" }
        extractor.selectTrack(trackIndex)

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        val bufferInfo = MediaCodec.BufferInfo()
        var sawInputEOS = false
        var sawOutputEOS = false

        var outSampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var outChannels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

        val timeoutUs = 10000L
        val useNewBufferApi = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
        @Suppress("DEPRECATION")
        val inputBuffers = if (useNewBufferApi) null else codec.inputBuffers
        @Suppress("DEPRECATION")
        var outputBuffers = if (useNewBufferApi) null else codec.outputBuffers

        var samplesCap = 1 shl 20
        var samples = ShortArray(samplesCap)
        var sampleCount = 0
        var leftoverByte: Byte? = null

        fun ensureCap(extra: Int) {
            if (sampleCount + extra > samplesCap) {
                while (sampleCount + extra > samplesCap) samplesCap *= 2
                samples = samples.copyOf(samplesCap)
            }
        }

        while (!sawOutputEOS) {
            if (!sawInputEOS) {
                val inIndex = codec.dequeueInputBuffer(timeoutUs)
                if (inIndex >= 0) {
                    val inBuffer = if (useNewBufferApi) {
                        codec.getInputBuffer(inIndex)!!
                    } else {
                        inputBuffers!![inIndex]
                    }
                    inBuffer.clear()
                    val sampleSize = extractor.readSampleData(inBuffer, 0)
                    if (sampleSize < 0) {
                        codec.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        sawInputEOS = true
                    } else {
                        codec.queueInputBuffer(inIndex, 0, sampleSize, extractor.sampleTime, 0)
                        extractor.advance()
                    }
                }
            }

            var outIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            while (outIndex >= 0) {
                when {
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val newFormat = codec.outputFormat
                        outSampleRate = newFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        outChannels = newFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    outIndex == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> {
                        if (!useNewBufferApi) {
                            @Suppress("DEPRECATION")
                            outputBuffers = codec.outputBuffers
                        }
                    }
                    else -> {
                        if (bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                            sawOutputEOS = true
                        }
                        if (bufferInfo.size > 0) {
                            val outBuffer = if (useNewBufferApi) {
                                codec.getOutputBuffer(outIndex)!!
                            } else {
                                outputBuffers!![outIndex]
                            }
                            outBuffer.position(bufferInfo.offset)
                            outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                            outBuffer.order(ByteOrder.LITTLE_ENDIAN)

                            var pos = outBuffer.position()
                            val limit = outBuffer.limit()

                            if (leftoverByte != null && pos < limit) {
                                val b0 = leftoverByte!!.toInt() and 0xFF
                                val b1 = outBuffer.get(pos).toInt() and 0xFF
                                ensureCap(1)
                                samples[sampleCount++] = ((b1 shl 8) or b0).toShort()
                                pos += 1
                                leftoverByte = null
                            }

                            val shortsHere = (limit - pos) / 2
                            if (shortsHere > 0) {
                                ensureCap(shortsHere)
                                var p = pos
                                for (i in 0 until shortsHere) {
                                    samples[sampleCount++] = outBuffer.getShort(p)
                                    p += 2
                                }
                                pos = p
                            }
                            if ((limit - pos) == 1) {
                                leftoverByte = outBuffer.get(pos)
                            }

                            outBuffer.clear()
                        }
                        codec.releaseOutputBuffer(outIndex, false)
                    }
                }
                outIndex = codec.dequeueOutputBuffer(bufferInfo, 0)
            }
        }

        codec.stop()
        codec.release()
        extractor.release()

        val finalSamples = if (sampleCount == samples.size) samples else samples.copyOf(sampleCount)
        return WavData(outChannels, outSampleRate, finalSamples)
    }

    private fun generateChannelPattern(wav: WavData, chanIndex: Int): PatternResult {
        val channels = wav.channels
        val totalFrames = wav.samples.size / channels

        val channelData = FloatArray(totalFrames)
        for (i in 0 until totalFrames) {
            channelData[i] = wav.samples[i * channels + chanIndex] / 32768f
        }

        val peak = channelData.maxOf { abs(it) }
        if (peak < 0.001f) return PatternResult(LongArray(0), DoubleArray(0))

        val frameLen = ANALYSIS_FRAME_LEN
        val hop = ANALYSIS_HOP
        val numFrames = max(1, (totalFrames - frameLen) / hop + 1)
        val frameDurationMs = (hop.toDouble() / wav.sampleRate) * 1000.0

        val rms = DoubleArray(numFrames)
        for (f in 0 until numFrames) {
            val start = f * hop
            val end = minOf(start + frameLen, totalFrames)
            var sumSq = 0.0
            for (i in start until end) sumSq += channelData[i].toDouble() * channelData[i].toDouble()
            rms[f] = Math.sqrt(sumSq / (end - start))
        }

        val thresholdLinear = peak * Math.pow(10.0, -TOP_DB / 20.0)
        val rawEnv = DoubleArray(numFrames) { (rms[it] / peak).coerceIn(0.0, 1.0) }
        val smoothWindow = max(4, (60.0 / frameDurationMs).toInt())
        val smoothEnv = DoubleArray(numFrames)
        for (f in 0 until numFrames) {
            val lo = max(0, f - smoothWindow)
            val hi = minOf(numFrames - 1, f + smoothWindow)
            var sum = 0.0
            for (k in lo..hi) sum += rawEnv[k]
            smoothEnv[f] = sum / (hi - lo + 1)
        }

        // Same approach as the live mode: envelope -> close dropouts -> long notes become ONE solid block.
        val env = DoubleArray(numFrames) {
            if (rms[it] > thresholdLinear) max(smoothEnv[it], 0.06) else 0.0
        }
        closeGaps(env, frameDurationMs)
        val solid = solidifyLongRuns(env, frameDurationMs)

        val pattern = ArrayList<Long>()
        val strengths = ArrayList<Double>()
        var cursor = 0L
        var f = 0
        while (f < numFrames) {
            if (env[f] <= ENV_ON_THRESHOLD) { f++; continue }
            val rs = f
            var sum = 0.0
            var peak2 = 0.0
            while (f < numFrames && env[f] > ENV_ON_THRESHOLD) {
                sum += env[f]
                if (env[f] > peak2) peak2 = env[f]
                f++
            }
            val st = Math.round(rs * frameDurationMs)
            val en = Math.round(f * frameDurationMs)
            if (en - st < 10L) continue
            if (st > cursor) {
                pattern.add(st - cursor)
                strengths.add(0.0)
                cursor = st
            }
            val dur = en - cursor
            val isSolid = solid[rs]
            val avgStrength = sum / (f - rs)
            pattern.add(dur)
            strengths.add(if (isSolid) peak2 else avgStrength)
            cursor = en
        }

        return PatternResult(pattern.toLongArray(), strengths.toDoubleArray())
    }

    private fun patternFromEnvelope(env: DoubleArray, frameMs: Double, offsetMs: Double, cfg: EnvCfg): PatternResult {
        closeGaps(env, frameMs)
        val numFrames = env.size
        val segs = ArrayList<FancySeg>()
        var rampCount = 0
        var f = 0
        while (f < numFrames) {
            if (env[f] <= ENV_ON_THRESHOLD) { f++; continue }
            val runStart = f
            while (f < numFrames && env[f] > ENV_ON_THRESHOLD) f++
            val runEnd = f
            val runStartMs = runStart * frameMs + offsetMs
            val runEndMs = runEnd * frameMs + offsetMs
            val runMs = runEndMs - runStartMs

            var runMax = 0.0
            for (k in runStart until runEnd) if (env[k] > runMax) runMax = env[k]

            if (runMs < cfg.tapMaxMs) {
                if (runMax >= 0.06 || runMs >= 4.0) {
                    segs.add(FancySeg(runStartMs, runEndMs, runMax, false))
                }
                continue
            }

            val steps = ArrayList<FancySeg>()
            var sStart = runStart
            var sMin = env[runStart]
            var sMax = sMin
            var sSum = sMin
            for (k in runStart + 1 until runEnd) {
                val v = env[k]
                val nMin = minOf(sMin, v)
                val nMax = maxOf(sMax, v)
                if (nMax - nMin <= cfg.tolerance) {
                    sMin = nMin; sMax = nMax; sSum += v
                } else {
                    steps.add(FancySeg(sStart * frameMs + offsetMs, k * frameMs + offsetMs, sSum / (k - sStart), false))
                    sStart = k; sMin = v; sMax = v; sSum = v
                }
            }
            steps.add(FancySeg(sStart * frameMs + offsetMs, runEndMs, sSum / (runEnd - sStart), false))

            val merged = ArrayList<FancySeg>()
            for (st in steps) {
                if (merged.isNotEmpty() && (st.endMs - st.startMs) < cfg.minStepMs) {
                    merged[merged.size - 1].endMs = st.endMs
                } else {
                    merged.add(st)
                }
            }

            var hiS = 0.0
            for (st in merged) if (st.strength > hiS) hiS = st.strength
            var pw = 0.0
            var pt = 0.0
            for (st in merged) {
                if (st.strength >= 0.75 * hiS) {
                    val d = st.endMs - st.startMs
                    pw += st.strength * d
                    pt += d
                }
            }
            val plateau = if (pt > 0.0) pw / pt else hiS

            var h = 0
            while (h < merged.size && merged[h].strength < 0.8 * plateau) h++
            val headOk = h >= 2 && h < merged.size &&
                (merged[h - 1].endMs - merged[0].startMs) >= cfg.fadeMinMs &&
                merged[0].strength <= 0.5 * plateau

            var t = merged.size
            while (t > h && merged[t - 1].strength < 0.8 * plateau) t--
            val tailOk = (merged.size - t) >= 2 && t > h &&
                (merged.last().endMs - merged[t].startMs) >= cfg.fadeMinMs &&
                merged.last().strength <= 0.5 * plateau

            if (!headOk) h = 0
            if (!tailOk) t = merged.size

            if (headOk) {
                for (i in 0 until h) {
                    merged[i].shaped = true
                    merged[i].strength = (merged[i].strength / plateau).coerceIn(0.0, 1.0)
                    segs.add(merged[i])
                }
                rampCount++
            }

            // Body of the note is always ONE solid block: no more cutting into steps/stairs
            // when the amplitude range is wide, since that staircase was the trembling/stepping.
            val bodyStart = merged[h].startMs
            val bodyEnd = merged[t - 1].endMs
            var weighted = 0.0
            var bodyPeak = 0.0
            for (i in h until t) {
                weighted += merged[i].strength * (merged[i].endMs - merged[i].startMs)
                if (merged[i].strength > bodyPeak) bodyPeak = merged[i].strength
            }
            val bodyMs = bodyEnd - bodyStart
            segs.add(FancySeg(bodyStart, bodyEnd, if (bodyMs > 0.0) weighted / bodyMs else bodyPeak, false))

            if (tailOk) {
                for (i in t until merged.size) {
                    merged[i].shaped = true
                    merged[i].strength = (merged[i].strength / plateau).coerceIn(0.0, 1.0)
                    segs.add(merged[i])
                }
                rampCount++
            }
        }

        if (segs.isEmpty()) return PatternResult(LongArray(0), DoubleArray(0))

        for (i in segs.indices) {
            val a = segs[i]
            val next = if (i + 1 < segs.size) segs[i + 1] else null
            if (a.endMs < a.startMs + cfg.minOnMs) {
                val want = a.startMs + cfg.minOnMs
                a.endMs = if (next != null) maxOf(a.endMs, minOf(want, next.startMs)) else want
            }
            if (next != null) {
                val gap = next.startMs - a.endMs
                if (gap > 0.0 && gap < cfg.minGapMs) a.endMs = next.startMs
            }
        }

        val durations = ArrayList<Long>()
        val strengths = ArrayList<Double>()
        val shaped = ArrayList<Boolean>()
        var cursor = 0L
        for (sg in segs) {
            val st = Math.round(sg.startMs)
            val en = Math.round(sg.endMs)
            if (st > cursor) {
                durations.add(st - cursor)
                strengths.add(0.0)
                shaped.add(false)
                cursor = st
            }
            val dur = en - cursor
            if (dur >= 1L) {
                durations.add(dur)
                strengths.add(sg.strength.coerceIn(0.0, 1.0))
                shaped.add(sg.shaped)
                cursor = en
            }
        }

        return PatternResult(
            durations.toLongArray(),
            strengths.toDoubleArray(),
            shaped.toBooleanArray(),
            rampCount
        )
    }

    private fun generateFancyPattern(wav: WavData, chanIndex: Int): PatternResult {
        val channels = wav.channels
        val sr = wav.sampleRate
        val totalFrames = wav.samples.size / channels
        if (totalFrames <= 0) return PatternResult(LongArray(0), DoubleArray(0))

        val winLen = max(64, (sr * 0.020).toInt()) // 20 ms: covers whole carrier cycles, no ripple
        val hop = max(8, (sr * 0.002).toInt())
        val numFrames = max(1, (totalFrames - winLen) / hop + 1)
        val frameMs = hop * 1000.0 / sr
        val offsetMs = (winLen - hop) / 2.0 * 1000.0 / sr

        val pk = DoubleArray(numFrames)
        for (f in 0 until numFrames) {
            val start = f * hop
            val end = minOf(start + winLen, totalFrames)
            var m = 0
            for (i in start until end) {
                val v = abs(wav.samples[i * channels + chanIndex].toInt())
                if (v > m) m = v
            }
            pk[f] = m / 32768.0
        }

        val sorted = pk.copyOf()
        sorted.sort()
        val ref = sorted[((numFrames - 1) * 0.995).toInt()]
        if (ref < 0.001) return PatternResult(LongArray(0), DoubleArray(0))
        val env = DoubleArray(numFrames) { (pk[it] / ref).coerceIn(0.0, 1.0) }

        val result = patternFromEnvelope(env, frameMs, offsetMs, CFG_ACH_FINE)
        Log.d(TAG, "generateFancyPattern: ${result.durations.size} segments, ${result.ramps} fades, ref=$ref")
        return result
    }

    private fun generateOtherPattern(wav: WavData, fine: Boolean): PatternResult {
        val channels = wav.channels
        val sr = wav.sampleRate
        val totalFrames = wav.samples.size / channels
        val hop = max(8, (sr * 0.004).toInt())
        val blocks = totalFrames / hop
        if (blocks < 8) return PatternResult(LongArray(0), DoubleArray(0))
        val winBlocks = 4

        val sqLow = DoubleArray(blocks)
        val sqMid = DoubleArray(blocks)
        val sqFull = DoubleArray(blocks)
        val aLow = 1.0 - Math.exp(-2.0 * Math.PI * 180.0 / sr)
        val aMid = 1.0 - Math.exp(-2.0 * Math.PI * 2000.0 / sr)
        var l1 = 0.0; var l2 = 0.0
        var m1 = 0.0; var m2 = 0.0
        val useCh = minOf(2, channels)
        for (b in 0 until blocks) {
            var sl = 0.0
            var sm = 0.0
            var sf = 0.0
            val base = b * hop
            for (i in base until base + hop) {
                var x = 0.0
                for (c in 0 until useCh) x += wav.samples[i * channels + c].toDouble()
                x /= (32768.0 * useCh)
                l1 += aLow * (x - l1); l2 += aLow * (l1 - l2)
                m1 += aMid * (x - m1); m2 += aMid * (m1 - m2)
                val mid = m2 - l2
                sl += l2 * l2
                sm += mid * mid
                sf += x * x
            }
            sqLow[b] = sl
            sqMid[b] = sm
            sqFull[b] = sf
        }

        val numFrames = blocks - winBlocks + 1
        val eLow = DoubleArray(numFrames)
        val eMid = DoubleArray(numFrames)
        val eFull = DoubleArray(numFrames)
        val denom = (winBlocks * hop).toDouble()
        var globalMax = 0.0
        for (f in 0 until numFrames) {
            var sl = 0.0
            var sm = 0.0
            var sf = 0.0
            for (k in 0 until winBlocks) {
                sl += sqLow[f + k]
                sm += sqMid[f + k]
                sf += sqFull[f + k]
            }
            eLow[f] = Math.sqrt(sl / denom)
            eMid[f] = Math.sqrt(sm / denom)
            eFull[f] = Math.sqrt(sf / denom)
            if (eFull[f] > globalMax) globalMax = eFull[f]
        }
        if (globalMax < 0.002) return PatternResult(LongArray(0), DoubleArray(0))

        val frameMs = hop * 1000.0 / sr
        val offsetMs = (winBlocks * hop - hop) / 2.0 * 1000.0 / sr

        val eBody = DoubleArray(numFrames) {
            Math.sqrt(eLow[it] * eLow[it] + 0.5 * eMid[it] * eMid[it])
        }
        val peakBody = localPeak(eBody, frameMs)
        val peakFull = localPeak(eFull, frameMs)
        val lookback = max(2, (60.0 / frameMs).toInt())

        val raw = DoubleArray(numFrames)
        var runSum = 0.0
        for (f in 0 until numFrames) {
            val cnt = minOf(f, lookback)
            val prevMean = if (cnt > 0) runSum / cnt else eFull[f]
            val onset = max(0.0, eFull[f] - prevMean) / peakFull[f]
            val bodyNorm = (eBody[f] / peakBody[f]).coerceIn(0.0, 1.0)
            val body = Math.pow(bodyNorm, 1.6)
            val hit = minOf(1.0, onset * 2.5)
            raw[f] = (0.75 * body + 0.45 * hit).coerceIn(0.0, 1.0)
            runSum += eFull[f]
            if (f - lookback >= 0) runSum -= eFull[f - lookback]
        }

        val attackCoef = 1.0 - Math.exp(-frameMs / 6.0)
        val releaseCoef = 1.0 - Math.exp(-frameMs / (if (fine) 70.0 else 110.0))
        val follow = DoubleArray(numFrames)
        var y = 0.0
        for (f in 0 until numFrames) {
            val coef = if (raw[f] > y) attackCoef else releaseCoef
            y += coef * (raw[f] - y)
            follow[f] = y
        }

        val onLevel = 0.30
        val offLevel = 0.18
        val holdFrames = max(1, ((if (fine) 40.0 else 60.0) / frameMs).toInt())
        val env = DoubleArray(numFrames)
        var open = false
        var lowCount = 0
        for (f in 0 until numFrames) {
            val v = follow[f]
            if (!open) {
                if (v >= onLevel) { open = true; lowCount = 0 }
            } else {
                if (v < offLevel) {
                    lowCount++
                    if (lowCount >= holdFrames) open = false
                } else {
                    lowCount = 0
                }
            }
            env[f] = if (open) ((v - offLevel * 0.5) / (1.0 - offLevel * 0.5)).coerceIn(0.0, 1.0) else 0.0
        }

        val result = patternFromEnvelope(env, frameMs, offsetMs, if (fine) CFG_OTHER_FINE else CFG_COARSE)
        Log.d(TAG, "generateOtherPattern: ${result.durations.size} segments, fine=$fine")
        return result
    }

    // Bridges short dropouts so one long vibration stays ONE long vibration.
    private fun closeGaps(env: DoubleArray, frameMs: Double) {
        val n = env.size
        val alwaysGap = max(1, (GAP_ALWAYS_MS / frameMs).toInt())
        val longGap = max(alwaysGap, (GAP_LONG_MS / frameMs).toInt())
        val fragGap = max(longGap, (GAP_FRAG_MAX_MS / frameMs).toInt())
        val longRun = max(1, (LONG_NOTE_MS / frameMs).toInt())
        var i = 0
        var prevStart = -1
        var prevEnd = -1
        var prevRaw = 0
        while (i < n) {
            if (env[i] <= ENV_ON_THRESHOLD) { i++; continue }
            val st = i
            while (i < n && env[i] > ENV_ON_THRESHOLD) i++
            val en = i
            val raw = en - st
            if (prevEnd >= 0) {
                val gap = st - prevEnd
                val nearLong = (prevEnd - prevStart) >= longRun || raw >= longRun
                // Compare with the RAW neighbouring pieces only (not the accumulated note),
                // otherwise every bridge makes the next gap look smaller and everything snowballs into one note.
                val fragmented = gap <= fragGap && gap <= minOf(prevRaw, raw) * GAP_RATIO
                if (gap in 1..fragGap && (gap <= alwaysGap || (nearLong && gap <= longGap) || fragmented)) {
                    val fill = max(0.12, minOf(env[prevEnd - 1], env[st]))
                    for (k in prevEnd until st) env[k] = fill
                    prevEnd = en
                    prevRaw = raw
                    continue
                }
            }
            prevStart = st
            prevEnd = en
            prevRaw = raw
        }
    }

    // Every long note (after gap closing) becomes ONE flat block at a single level.
    // Returns a mask of the frames that belong to long notes.
    private fun solidifyLongRuns(env: DoubleArray, frameMs: Double): BooleanArray {
        val mask = BooleanArray(env.size)
        val longRun = max(1, (LONG_NOTE_MS / frameMs).toInt())
        var i = 0
        while (i < env.size) {
            if (env[i] <= ENV_ON_THRESHOLD) { i++; continue }
            val st = i
            var peak = 0.0
            while (i < env.size && env[i] > ENV_ON_THRESHOLD) {
                if (env[i] > peak) peak = env[i]
                i++
            }
            if (i - st >= longRun) {
                for (k in st until i) { env[k] = peak; mask[k] = true }
            }
        }
        return mask
    }

    private fun localPeak(e: DoubleArray, frameMs: Double): DoubleArray {
        val n = e.size
        val blockFrames = max(1, (250.0 / frameMs).toInt())
        val numBlocks = (n + blockFrames - 1) / blockFrames
        val blockMax = DoubleArray(numBlocks)
        var globalMax = 0.0
        for (i in 0 until n) {
            val b = i / blockFrames
            if (e[i] > blockMax[b]) blockMax[b] = e[i]
            if (e[i] > globalMax) globalMax = e[i]
        }
        val floor = max(globalMax * 0.05, 1e-9)
        val reach = 5
        val out = DoubleArray(n)
        for (i in 0 until n) {
            val b = i / blockFrames
            var m = 0.0
            for (k in max(0, b - reach)..minOf(numBlocks - 1, b + reach)) {
                if (blockMax[k] > m) m = blockMax[k]
            }
            out[i] = max(m, floor)
        }
        return out
    }
}

private class Tls12SocketFactory(private val delegate: SSLSocketFactory) : SSLSocketFactory() {

    private fun enable(socket: Socket): Socket {
        if (socket is SSLSocket) {
            val wanted = listOf("TLSv1.2", "TLSv1.1", "TLSv1")
            val usable = wanted.filter { it in socket.supportedProtocols }
            if (usable.isNotEmpty()) socket.enabledProtocols = usable.toTypedArray()
        }
        return socket
    }

    override fun getDefaultCipherSuites(): Array<String> = delegate.defaultCipherSuites

    override fun getSupportedCipherSuites(): Array<String> = delegate.supportedCipherSuites

    override fun createSocket(s: Socket, host: String, port: Int, autoClose: Boolean): Socket =
        enable(delegate.createSocket(s, host, port, autoClose))

    override fun createSocket(host: String, port: Int): Socket =
        enable(delegate.createSocket(host, port))

    override fun createSocket(host: String, port: Int, localHost: InetAddress, localPort: Int): Socket =
        enable(delegate.createSocket(host, port, localHost, localPort))

    override fun createSocket(host: InetAddress, port: Int): Socket =
        enable(delegate.createSocket(host, port))

    override fun createSocket(address: InetAddress, port: Int, localAddress: InetAddress, localPort: Int): Socket =
        enable(delegate.createSocket(address, port, localAddress, localPort))
}
